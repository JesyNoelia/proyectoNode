-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2021 at 04:52 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbdd_colegios`
--
DROP DATABASE IF EXISTS `bbdd_colegios`;
CREATE DATABASE IF NOT EXISTS `bbdd_colegios` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `bbdd_colegios`;

-- --------------------------------------------------------

--
-- Table structure for table `articulos`
--

DROP TABLE IF EXISTS `articulos`;
CREATE TABLE `articulos` (
  `id` int(11) NOT NULL,
  `titulo` varchar(45) CHARACTER SET utf8mb4 NOT NULL,
  `precio` decimal(10,2) UNSIGNED NOT NULL,
  `descripcion` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `talla` varchar(6) CHARACTER SET utf8mb4 DEFAULT NULL,
  `curso` varchar(20) CHARACTER SET utf8mb4 DEFAULT NULL,
  `estado` varchar(30) CHARACTER SET utf8mb4 NOT NULL,
  `imagen` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `disponible` tinyint(1) NOT NULL,
  `fk_usuario` int(11) NOT NULL,
  `fk_categoria` int(11) NOT NULL,
  `fk_colegio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `articulos`
--

INSERT INTO `articulos` (`id`, `titulo`, `precio`, `descripcion`, `talla`, `curso`, `estado`, `imagen`, `disponible`, `fk_usuario`, `fk_categoria`, `fk_colegio`) VALUES
(3, 'Jersey granate cuello pico', '15.00', 'Jersey granate con cuello de pico y manga larga.', 's', '2', 'Bueno', 'https://asset1.cxnmarksandspencer.com/is/image/mands/SD_04_T76_3920_XM_X_EC_1?$PDP_INT_IMAGE_DESKTOP_DOUBLE$', 1, 1, 1, 0),
(4, 'Mochila azul ', '7.00', 'Mochila tela vaquera azul, doble cierre de cremalleras', NULL, NULL, 'Bueno', 'https://img.milanuncios.com/fg/3621/96/362196940_1.jpg?VersionId=4hlH5bTFFgpQGJNJUOMyIyXj4nJvOk..', 1, 2, 2, 0),
(5, 'Estuche completo', '5.00', 'estuche de cremallera para pinturas y lapices', NULL, NULL, 'Falta la gomna', 'https://eresmama.com/wp-content/uploads/2018/04/estuche-colegio.jpg', 1, 1, 2, 0),
(6, 'Compás', '10.00', 'Compás en caja con recambio de minas', NULL, NULL, 'Usado, minas un poc gastadas', 'https://www.carlin.es/archivos/productos/16085-550-02.jpg-1584983790.jpg', 1, 9, 2, 1),
(7, 'LIbros Lengua Castellana', '12.00', 'Liros de lengua Castellana. Todos los trimestres y libro de ejercicios', NULL, '4', 'Usado y borrado', 'https://i.imgur.com/M8f5l0y.jpg', 1, 6, 4, 3),
(8, ':ibro de matemáticas', '8.00', 'Libro de matematicas con ejercicios', NULL, '3', 'Sin usar', 'https://images-na.ssl-images-amazon.com/images/I/71l-f936NyL.jpg', 1, 7, 4, 2),
(9, 'Matemáticas', '7.50', 'Libro de matemáticas anual con ejercicios', NULL, '5', 'Bueno, esquinas desgastadas', 'https://relibrea.com/imagenes/23970/179044/libro-de-matematicas-5-de-primaria-editorial-santillana_1.jpg?v2', 1, 6, 4, 1),
(10, 'Libro de geografía', '10.50', 'Libro de geografia, anexo con mapas', NULL, '5', 'Muy usado', 'https://www.elsotano.com/imagenes_grandes/7506007/750600758762.JPG', 1, 5, 4, 3),
(11, 'Calculadora científica', '15.00', 'Calculadora científica', NULL, NULL, 'Usado, pilas recién cambiadas', 'https://sgfm.elcorteingles.es/SGFM/dctm/MEDIA03/201805/30/00106652175156____6__640x640.jpg', 1, 2, 5, 2),
(12, 'Pelota de baloncesto', '8.00', 'Pelota de baloncesto naranja', NULL, NULL, 'muy bueno', 'https://images-na.ssl-images-amazon.com/images/I/81KIDFmwumL._AC_SL1500_.jpg', 1, 3, 3, 1),
(13, 'kimono Karate', '15.50', 'Kimono de karate blanco, sin cinturon', 'm', NULL, 'Bueno', 'https://static.carrefour.es/hd_510x_/imagenes/products/84254/02224/670/8425402224670/imagenGrande1.jpg', 1, 5, 3, 2),
(14, 'Raqueta de tenis', '9.00', 'Raqueta de tenis, color azul. Buen agarre para manos pequeñas', NULL, NULL, 'Usado', 'https://shop.wilson.com/es-es/media/catalog/product/cache/152/image/9df78eab33525d08d6e5fb8d27136e95/0/d/0d489e9d43bdecd1a8385fb4cca137c40649905e_WRT30560U_US_Open_Version_2_Gloss_Blue_Yellow_Front.jpg', 1, 3, 3, 1),
(15, 'Tablet Samsung', '125.00', 'Tablet Samsunf Galaxy comprada en 2020', NULL, NULL, 'Usada', 'https://i.blogs.es/42aebd/porti/1366_2000.png', 1, 4, 5, 3),
(20, 'Pantalon largo azul marino', '9.50', 'Pantalón largo azul marino. ', 'm', '4', 'Bueno', 'https://www.pronens.com/sites/default/files/pantalon_vestir.png', 1, 2, 1, 3),
(21, 'Falda de cuadros grises', '10.00', 'Falda corta de cuadros grises.', 's', '2', 'Usado', 'https://ruisell.com/wp-content/uploads/2019/05/ref-8046-falda-plisada01-800x800.jpg', 1, 7, 1, 2),
(22, 'Falda plisada gris', '12.50', 'Falda gris con tirantes', 'm', '5', 'Sin usar', 'https://cdn.shopify.com/s/files/1/2992/2084/products/falda-de-colegio-de-tablas-lana-todoparaelcole-2_2048x.jpg?v=1620291028', 1, 3, 1, 0),
(23, 'Zapatos azul marino', '5.50', 'Zapatos azul marino con velcro', '30', '1', 'Bueno', 'https://calzadosnicolas.es/wp-content/uploads/2015/08/COLEGIAL-VELCRO-SLADAM-8451.jpg', 1, 4, 1, 2),
(24, 'Carpetas anillas azul y rosa', '2.00', 'carpetas 4 anillas azul y rosa', NULL, NULL, 'Bueno', 'https://www.carlinasturias.com/archivos/productos/0406701AZ.jpg', 1, 2, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(1, 'Uniformes'),
(2, 'Material Escolar'),
(3, 'Material Deportivo'),
(4, 'Libros'),
(5, 'Tecnología'),
(6, 'Juguetes Didácticos');

-- --------------------------------------------------------

--
-- Table structure for table `colegios`
--

DROP TABLE IF EXISTS `colegios`;
CREATE TABLE `colegios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `direccion` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `telefono` varchar(15) CHARACTER SET utf8mb4 NOT NULL,
  `codigo_centro` char(8) CHARACTER SET utf8mb4 NOT NULL,
  `web` varchar(60) CHARACTER SET utf8mb4 NOT NULL,
  `longitud` float NOT NULL,
  `latitud` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `colegios`
--

INSERT INTO `colegios` (`id`, `nombre`, `direccion`, `telefono`, `codigo_centro`, `web`, `longitud`, `latitud`) VALUES
(1, 'La Merced', 'C. Luis de Góngora, 5, 28004 Madrid', '915 23 22 99', '28013255', 'https://www.colegiolamerced.es/', 40.4241, -3.69703),
(2, 'Purisima Concepcion', 'C. Puebla 20', '915 219 758', '28008791', 'https://pconcepcion.escuelateresiana.com/', 40.4236, -3.70332),
(3, 'Real Colegio de Santa Isabel la Asunción', 'C. Santa Isabel, 46', '91 527 31 81', '28009549', 'http://www.santaisabelmadrid.com/', 40.4099, -3.69678);

-- --------------------------------------------------------

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `numero_pedido` varchar(60) CHARACTER SET utf8mb4 NOT NULL,
  `fecha_pedido` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fk_usuario` int(11) NOT NULL,
  `fk_articulo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pedidos`
--

INSERT INTO `pedidos` (`id`, `numero_pedido`, `fecha_pedido`, `fk_usuario`, `fk_articulo`) VALUES
(1, 'pedido_1623854089241', '2021-06-16 14:34:49', 5, 3);

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) CHARACTER SET utf8mb4 NOT NULL,
  `apellidos` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `telefono` varchar(15) CHARACTER SET utf8mb4 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `fk_colegio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellidos`, `email`, `telefono`, `password`, `fecha_registro`, `fk_colegio`) VALUES
(1, 'Alicia', 'García', 'ali@gmail.com', '123456789', '123456', '2021-06-02 14:46:49', 0),
(2, 'Jesica', 'Rosales', 'jesi@gmail.com', '987654321', '123456', '2021-06-02 14:46:49', 0),
(3, 'Carlos', 'López', 'carlos@gmail.com', '778654534', '2323', '2021-06-14 09:10:39', 1),
(6, 'Lucia', 'Estrella', 'lucia@gmail.com', '998987867', '1111', '2021-06-14 09:12:15', 2),
(7, 'Maria', 'Rúiz', 'mari@gmail.com', '445453432', '12389', '2021-06-14 09:12:15', 2),
(8, 'Pedro', 'Alvarez', 'pedro@gmail.com', '2345456768', '3434', '2021-06-14 09:12:15', 1),
(9, 'Alberto', 'Hervas', 'alberto@gmail.com', '667675656', '121212', '2021-06-14 09:12:45', 2),
(10, 'Maria', 'Perez Gonzalez', 'marian@hotmail.com', '654789321', '123456', '2021-06-15 12:22:54', 3),
(11, 'Jimena', 'Morales', 'jimemorales@hotmail.com', '569874258', '123456', '2021-06-16 08:09:13', 3),
(12, 'Jose', 'Martinez', 'josemartinez@hotmail.com', '654789321', '$2a$10$JpeELKLWbRSUIO/C5SMeh.41EOrU4oEGcF0SUfTG5nxRtstJalYh6', '2021-06-16 08:36:18', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articulos`
--
ALTER TABLE `articulos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_CATEGORIA` (`fk_categoria`),
  ADD KEY `FK_USUARIO` (`fk_usuario`),
  ADD KEY `FK_COLEGIO` (`fk_colegio`);

--
-- Indexes for table `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `colegios`
--
ALTER TABLE `colegios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo_centro_UNIQUE` (`codigo_centro`);

--
-- Indexes for table `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_USUARIO` (`fk_usuario`),
  ADD KEY `FK_ARTICULO` (`fk_articulo`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD KEY `FK_COLEGIO` (`fk_colegio`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articulos`
--
ALTER TABLE `articulos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `colegios`
--
ALTER TABLE `colegios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
