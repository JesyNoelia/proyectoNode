-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jun 24, 2021 at 11:07 AM
-- Server version: 5.7.32
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbdd_colegios`
--
DROP DATABASE IF EXISTS `bbdd_colegios`;
CREATE DATABASE IF NOT EXISTS `bbdd_colegios` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `bbdd_colegios`;

-- --------------------------------------------------------

--
-- Table structure for table `articulos`
--

DROP TABLE IF EXISTS `articulos`;
CREATE TABLE `articulos` (
  `id` int(11) NOT NULL,
  `titulo` varchar(45) CHARACTER SET utf8mb4 NOT NULL,
  `precio` decimal(10,2) UNSIGNED NOT NULL,
  `descripcion` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `talla` varchar(6) CHARACTER SET utf8mb4 DEFAULT NULL,
  `curso` varchar(20) CHARACTER SET utf8mb4 DEFAULT NULL,
  `estado` varchar(30) CHARACTER SET utf8mb4 NOT NULL,
  `imagen` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `disponible` tinyint(1) NOT NULL,
  `fk_usuario` int(11) NOT NULL,
  `fk_categoria` int(11) NOT NULL,
  `fk_colegio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `articulos`
--

INSERT INTO `articulos` (`id`, `titulo`, `precio`, `descripcion`, `talla`, `curso`, `estado`, `imagen`, `disponible`, `fk_usuario`, `fk_categoria`, `fk_colegio`) VALUES
(3, 'Jersey granate cuello pico', '15.00', 'Jersey granate con cuello de pico y manga larga.', 's', '2', 'Bueno', 'https://asset1.cxnmarksandspencer.com/is/image/mands/SD_04_T76_3920_XM_X_EC_1?$PDP_INT_IMAGE_DESKTOP_DOUBLE$', 0, 1, 1, 0),
(4, 'Mochila azul ', '7.00', 'Mochila tela vaquera azul, doble cierre de cremalleras', NULL, NULL, 'Bueno', 'https://img.milanuncios.com/fg/3621/96/362196940_1.jpg?VersionId=4hlH5bTFFgpQGJNJUOMyIyXj4nJvOk..', 1, 2, 2, 0),
(5, 'Estuche completo', '5.00', 'estuche de cremallera para pinturas y lapices', NULL, NULL, 'Falta la gomna', 'https://eresmama.com/wp-content/uploads/2018/04/estuche-colegio.jpg', 1, 1, 2, 0),
(6, 'Compás', '10.00', 'Compás en caja con recambio de minas', NULL, NULL, 'Usado, minas un poc gastadas', 'https://www.carlin.es/archivos/productos/16085-550-02.jpg-1584983790.jpg', 1, 9, 2, 1),
(7, 'LIbros Lengua Castellana', '12.00', 'Liros de lengua Castellana. Todos los trimestres y libro de ejercicios', NULL, '4', 'Usado y borrado', 'https://i.imgur.com/M8f5l0y.jpg', 1, 6, 4, 3),
(8, 'Libro de matemáticas', '8.00', 'Libro de matematicas con ejercicios', NULL, '3', 'Sin usar', 'https://images-na.ssl-images-amazon.com/images/I/71l-f936NyL.jpg', 1, 7, 4, 2),
(9, 'Matemáticas', '7.50', 'Libro de matemáticas anual con ejercicios', NULL, '5', 'Bueno, esquinas desgastadas', 'https://relibrea.com/imagenes/23970/179044/libro-de-matematicas-5-de-primaria-editorial-santillana_1.jpg?v2', 1, 6, 4, 1),
(10, 'Libro de geografía', '10.50', 'Libro de geografia, anexo con mapas', NULL, '5', 'Muy usado', 'https://www.elsotano.com/imagenes_grandes/7506007/750600758762.JPG', 1, 5, 4, 3),
(11, 'Calculadora científica', '15.00', 'Calculadora científica', NULL, NULL, 'Usado, pilas recién cambiadas', 'https://sgfm.elcorteingles.es/SGFM/dctm/MEDIA03/201805/30/00106652175156____6__640x640.jpg', 1, 2, 5, 2),
(12, 'Pelota de baloncesto', '8.00', 'Pelota de baloncesto naranja', NULL, NULL, 'muy bueno', 'https://images-na.ssl-images-amazon.com/images/I/81KIDFmwumL._AC_SL1500_.jpg', 1, 3, 3, 1),
(13, 'kimono Karate', '15.50', 'Kimono de karate blanco, sin cinturon', 'm', NULL, 'Bueno', 'https://static.carrefour.es/hd_510x_/imagenes/products/84254/02224/670/8425402224670/imagenGrande1.jpg', 1, 5, 3, 2),
(14, 'Raqueta de tenis', '9.00', 'Raqueta de tenis, color azul. Buen agarre para manos pequeñas', NULL, NULL, 'Usado', 'https://shop.wilson.com/es-es/media/catalog/product/cache/152/image/9df78eab33525d08d6e5fb8d27136e95/0/d/0d489e9d43bdecd1a8385fb4cca137c40649905e_WRT30560U_US_Open_Version_2_Gloss_Blue_Yellow_Front.jpg', 1, 3, 3, 1),
(15, 'Tablet Samsung', '125.00', 'Tablet Samsunf Galaxy comprada en 2020', NULL, NULL, 'Usada', 'https://i.blogs.es/42aebd/porti/1366_2000.png', 1, 4, 5, 3),
(20, 'Pantalon largo azul marino', '9.50', 'Pantalón largo azul marino. ', 'm', '4', 'Bueno', 'https://www.pronens.com/sites/default/files/pantalon_vestir.png', 1, 2, 1, 3),
(21, 'Falda de cuadros grises', '10.00', 'Falda corta de cuadros grises.', 's', '2', 'Usado', 'https://ruisell.com/wp-content/uploads/2019/05/ref-8046-falda-plisada01-800x800.jpg', 1, 7, 1, 2),
(22, 'Falda plisada gris', '12.50', 'Falda gris con tirantes', 'm', '5', 'Sin usar', 'https://cdn.shopify.com/s/files/1/2992/2084/products/falda-de-colegio-de-tablas-lana-todoparaelcole-2_2048x.jpg?v=1620291028', 1, 3, 1, 0),
(23, 'Zapatos azul marino', '5.50', 'Zapatos azul marino con velcro', '30', '1', 'Bueno', 'https://calzadosnicolas.es/wp-content/uploads/2015/08/COLEGIAL-VELCRO-SLADAM-8451.jpg', 1, 4, 1, 2),
(24, 'Carpetas anillas azul y rosa', '2.00', 'carpetas 4 anillas azul y rosa', NULL, NULL, 'Bueno', 'https://www.carlinasturias.com/archivos/productos/0406701AZ.jpg', 1, 2, 2, 3),
(30, 'Lápices de colores', '4.00', 'Varios lapices de colores', 'null', 'null', 'Como Nuevo', 'http://localhost:3000/images/72bc54e4335ade00382621258ba3f79d.jpeg', 1, 12, 2, 1),
(31, 'Pelota', '3.00', 'Pelota de futbol con dibujos de unicornios', 'null', NULL, 'En buen estado', 'http://localhost:3000/images/4670309e960ca0406fdc20363871af96.jpeg', 1, 14, 3, 2),
(32, 'Zapatilla de niño', '15.00', 'Zapatillas adidas para niños', NULL, NULL, 'En buen estado', 'http://localhost:3000/images/92d4f2419277f990dfc17a629a1e11c3.jpeg', 1, 12, 3, 2),
(33, 'Falda gris', '3.00', 'Falda Gris', '5', '2 Primaria', 'En buen estado', 'http://localhost:3000/images/3fef8a1b5c62d08f408cd2971d3de55d.jpeg', 1, 14, 1, 2),
(34, 'Abaco', '5.00', 'Abaco', NULL, NULL, 'En buen estado', 'http://localhost:3000/images/3d925f07f9fa3d72930c1269edc28f5c.jpeg', 1, 12, 6, 2),
(35, 'Set de reglas', '2.50', 'Set de reglas', NULL, NULL, 'Sin Estrenar', 'http://localhost:3000/images/83ac33b2b71f023473f6721eb27da0f1.jpeg', 1, 14, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(1, 'Uniformes'),
(2, 'Material Escolar'),
(3, 'Material Deportivo'),
(4, 'Libros'),
(5, 'Tecnología'),
(6, 'Juguetes Didácticos');

-- --------------------------------------------------------

--
-- Table structure for table `colegios`
--

DROP TABLE IF EXISTS `colegios`;
CREATE TABLE `colegios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `direccion` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `telefono` varchar(15) CHARACTER SET utf8mb4 NOT NULL,
  `codigo_centro` char(8) CHARACTER SET utf8mb4 NOT NULL,
  `web` varchar(60) CHARACTER SET utf8mb4 NOT NULL,
  `latitud` float NOT NULL,
  `longitud` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `colegios`
--

INSERT INTO `colegios` (`id`, `nombre`, `direccion`, `telefono`, `codigo_centro`, `web`, `latitud`, `longitud`) VALUES
(1, 'La Merced', 'C. Luis de Góngora, 5, 28004 Madrid', '915 23 22 99', '28013255', 'https://www.colegiolamerced.es/', 40.4241, -3.69703),
(2, 'Purisima Concepcion', 'C. Puebla 20', '915 219 758', '28008791', 'https://pconcepcion.escuelateresiana.com/', 40.4236, -3.70332),
(3, 'Real Colegio de Santa Isabel la Asunción', 'C. Santa Isabel, 46', '91 527 31 81', '28009549', 'http://www.santaisabelmadrid.com/', 40.4099, -3.69678),
(4, 'EEI \"CARRICOCHE\"', 'Calle De Moreja 1, 28041, Madrid (Usera).', '913170465', '28043491', 'http://www.educa.madrid.org/eei.carricoche.madrid', 40.3706, -3.69934),
(5, 'CP INF-PRI \"TIRSO DE MOLINA\"', ' Calle Del Bronce 1, 28045, Madrid (Arganzuela)', '915278932', '28006408', ' http://www.educa.madrid.org/cp.tirsodemolina.madrid', 40.3685, -3.69822),
(6, 'CP INF-PRI \"LEGADO CRESPO\"', 'Paseo De Las Acacias 2, 28005, Madrid (Arganzuela).', '915286325', '28010761', 'http://www.educa.madrid.org/cp.legadocrespo.madrid', 40.405, -3.70388),
(7, 'CP INF-PRI \"JOAQUIN COSTA\"', 'Paseo De Pontones 8, 28005, Madrid (Arganzuela).', ' 913653632 ', '28010722', 'http://www.educa.madrid.org/cp.joaquincosta.madrid', 40.4061, -3.7148),
(8, 'EEI \"EL TREN DE LA FRESA\"', 'Calle De Ramírez De Prado 6, 28045, Madrid (Arganzuela).', '915399458', '28068271', 'http://www.educa.madrid.org/eei.trendelafresa.madrid', 40.3994, -3.68805),
(9, 'CP INF-PRI \"MENENDEZ Y PELAYO\"', 'Calle De Méndez Álvaro 16, 28045, Madrid (Arganzuela).', '915272781', '28005881', 'http://www.educa.madrid.org/cp.menendezypelayo.madrid', 40.4058, -3.69144),
(10, 'CP INF-PRI \"MIGUEL DE UNAMUNO\"', 'Calle De Alicante 5, 28045, Madrid (Arganzuela)', '915282554', '28010850', 'http://www.educa.madrid.org/cp.unamuno.madrid', 40.3945, -3.6935),
(18, 'CP INF-PRI \"PLACIDO DOMINGO\"', 'Calle Del Tejo 5, 28045, Madrid (Arganzuela).', '917650789', '28071371', 'http://www.educa.madrid.org/cp.placidodomingo.madrid', 40.3975, -3.67843),
(19, 'CP INF-PRI \"SAN EUGENIO Y SAN ISIDRO\"', 'Calle De Peñuelas 31, 28005, Madrid (Arganzuela).', '914737711', '28006275', 'http://www.educa.madrid.org/cp.saneugenio.madrid', 40.4025, -3.70316),
(20, 'IES \"JUAN DE LA CIERVA\"', 'Calle De La Caoba 1, 28005, Madrid (Arganzuela).', '915064610', '28020910', 'http://www.educa.madrid.org/ies.juandelacierva.madrid', 40.4024, -3.70638),
(21, 'CP INF-PRI \"TOMAS BRETON\"', 'Calle De Alejandro Dumas 4, 28005, Madrid (Arganzuela).', '913642214', '28010394', 'http://www.educa.madrid.org/cp.tomasbreton.madrid', 40.4015, -3.71622),
(22, 'CEPA \"ARGANZUELA\"', ' Calle De La Batalla Del Salado 29, 28045, Madrid (Arganzuela).', '915395395', '28045608', ' http://www.educa.madrid.org/cepa.arganzuela.madrid', 40.4007, -3.69603),
(23, 'IES \"ANTONIO FRAGUAS FORGES\"', 'Calle Alberche s/n, 28045, Madrid (Arganzuela).', '918175930', '28078559', ' http://www.educa.madrid.org/ies.forges.madrid', 40.3999, -3.67921),
(24, 'IES \"GRAN CAPITÁN\"', 'Paseo De Los Melancólicos 51, 28005, Madrid (Arganzuela).', '913659190', '28021562', ' http://www.educa.madrid.org/ies.grancapitan.madrid', 40.4038, -3.71987),
(25, 'CP INF-PRI \"PI I MARGALL\"', ' Plaza Del Dos De Mayo 2, 28004, Madrid (Centro).', '915323420', '28010679', ' http://www.educa.madrid.org/cp.piimargall.madrid', 40.427, -3.70457),
(26, 'CP INF-PRI \"SAN ILDEFONSO\"', 'Calle De Alfonso Vi 1, 28005, Madrid (Centro).', '913643923', '28006317', 'http://www.educa.madrid.org/cp.sanildefonso.madrid', 40.4131, -3.71219),
(27, 'CP INF-PRI \"SANTA MARIA\"', 'Calle Del Casino 7, 28005, Madrid (Centro).', '915275281', '28006381', 'http://www.educa.madrid.org/cp.santamaria.madrid', 40.4062, -3.70681),
(28, 'CP INF-PRI \"VAZQUEZ DE MELLA\"', 'Calle De Bailén 18, 28005, Madrid (Centro).', '913654878', '28011040', 'http://www.educa.madrid.org/cp.vazquezdemella.madrid', 40.4122, -3.71421),
(29, 'IES \"CARDENAL CISNEROS\"', 'Calle De Los Reyes 4, 28015, Madrid (Centro).', '915224869', '28020934', 'http://www.educa.madrid.org/ies.cardenalcisnero.madrid', 40.4246, -3.70828),
(30, 'IES \"LOPE DE VEGA\"', 'Calle De San Bernardo 70, 28015, Madrid (Centro).', '915321362', '28019889', 'http://www.educa.madrid.org/ies.lopedevega.madrid', 40.4272, -3.70636),
(31, 'IES \"SAN MATEO\"', 'Calle De La Beneficencia 4, 28004, Madrid (Centro).', '912760274', '28030939', 'http://www.educa.madrid.org/ies.sanmateo.madrid', 40.4258, -3.70022);

-- --------------------------------------------------------

--
-- Table structure for table `favoritos`
--

DROP TABLE IF EXISTS `favoritos`;
CREATE TABLE `favoritos` (
  `id` int(11) NOT NULL,
  `fk_usuario` int(11) NOT NULL,
  `fk_articulo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `favoritos`
--

INSERT INTO `favoritos` (`id`, `fk_usuario`, `fk_articulo`) VALUES
(1, 2, 8),
(2, 5, 9),
(3, 3, 15),
(4, 8, 7),
(5, 14, 4),
(6, 14, 5),
(7, 14, 11),
(8, 14, 14),
(9, 16, 4),
(10, 16, 4),
(11, 16, 5),
(12, 16, 6),
(13, 16, 6);

-- --------------------------------------------------------

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `numero_pedido` varchar(60) CHARACTER SET utf8mb4 NOT NULL,
  `fecha_pedido` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fk_usuario` int(11) NOT NULL,
  `fk_articulo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pedidos`
--

INSERT INTO `pedidos` (`id`, `numero_pedido`, `fecha_pedido`, `fk_usuario`, `fk_articulo`) VALUES
(1, 'pedido_1623854089241', '2021-06-16 14:34:49', 5, 3),
(2, 'pedido_1623924229060', '2021-06-17 10:03:49', 5, 14),
(3, 'pedido_1624346543818', '2021-06-22 07:22:23', 5, 12),
(4, 'pedido_1624346543818', '2021-06-22 07:22:23', 5, 11),
(5, 'pedido_1624351520863', '2021-06-22 08:45:20', 12, 8),
(6, 'pedido_1624351520863', '2021-06-22 08:45:20', 12, 9),
(7, 'pedido_1624530997641', '2021-06-24 10:36:37', 16, 10),
(8, 'pedido_1624530997641', '2021-06-24 10:36:37', 16, 3),
(9, 'pedido_1624530997641', '2021-06-24 10:36:37', 16, 6);

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) CHARACTER SET utf8mb4 NOT NULL,
  `apellidos` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `telefono` varchar(15) CHARACTER SET utf8mb4 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fk_colegio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellidos`, `email`, `telefono`, `password`, `fecha_registro`, `fk_colegio`) VALUES
(1, 'Alicia', 'García', 'ali@gmail.com', '123456789', '123456', '2021-06-02 14:46:49', 0),
(2, 'Jesica', 'Rosales', 'jesi@gmail.com', '987654321', '123456', '2021-06-02 14:46:49', 0),
(3, 'Carlos', 'López', 'carlos@gmail.com', '778654534', '2323', '2021-06-14 09:10:39', 1),
(6, 'Lucia', 'Estrella', 'lucia@gmail.com', '998987867', '1111', '2021-06-14 09:12:15', 2),
(7, 'Maria', 'Rúiz', 'mari@gmail.com', '445453432', '12389', '2021-06-14 09:12:15', 2),
(8, 'Pedro', 'Alvarez', 'pedro@gmail.com', '2345456768', '3434', '2021-06-14 09:12:15', 1),
(9, 'Alberto', 'Hervas', 'alberto@gmail.com', '667675656', '121212', '2021-06-14 09:12:45', 2),
(10, 'Maria', 'Perez Gonzalez', 'marian@hotmail.com', '654789321', '123456', '2021-06-15 12:22:54', 3),
(11, 'Jimena', 'Morales', 'jimemorales@hotmail.com', '569874258', '123456', '2021-06-16 08:09:13', 3),
(12, 'Jose', 'Martinez', 'josemartinez@hotmail.com', '654789321', '$2a$10$JpeELKLWbRSUIO/C5SMeh.41EOrU4oEGcF0SUfTG5nxRtstJalYh6', '2021-06-16 08:36:18', 3),
(14, 'Juan Pablo', 'Gimenez', 'jpgimenez@gmail.com', '+34569871236', '$2a$10$fL.1/Um7KhDHvkBptnJN5uEejbMiT1UibVIDC2CwmK59KYJX674ZO', '2021-06-22 08:49:23', 1),
(15, 'Prueba1', 'prueba1', 'prueba1@gmail.com', '112211221122', '$2a$10$Es2AFjXdgv8avyyi8SXtf.8uRoMiG.bJ04iCd/A75rbAW4mZFRgqa', '2021-06-23 08:04:14', 2),
(16, 'MariJose', 'Fernández', 'marijose@gmail.com', '112211221', '$2a$10$lP6mzvPtf2XPgDFd24O/OOhS.S8UILDbt47R7tpSEW8nuwfrV.5Zy', '2021-06-23 08:35:16', 3),
(17, 'Pablo', 'García', 'pablogarcia@gmail.com', '555555555', '$2a$10$st5Y6clrj0tFjcxU7OxDluF0DYGY.ZYQmXr4gRwO349ssuI1xDjMi', '2021-06-24 10:49:23', 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articulos`
--
ALTER TABLE `articulos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_CATEGORIA` (`fk_categoria`),
  ADD KEY `FK_USUARIO` (`fk_usuario`),
  ADD KEY `FK_COLEGIO` (`fk_colegio`);

--
-- Indexes for table `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `colegios`
--
ALTER TABLE `colegios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo_centro_UNIQUE` (`codigo_centro`);

--
-- Indexes for table `favoritos`
--
ALTER TABLE `favoritos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_USUARIO` (`fk_usuario`),
  ADD KEY `FK_ARTICULO` (`fk_articulo`);

--
-- Indexes for table `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_USUARIO` (`fk_usuario`),
  ADD KEY `FK_ARTICULO` (`fk_articulo`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD KEY `FK_COLEGIO` (`fk_colegio`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articulos`
--
ALTER TABLE `articulos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `colegios`
--
ALTER TABLE `colegios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `favoritos`
--
ALTER TABLE `favoritos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
