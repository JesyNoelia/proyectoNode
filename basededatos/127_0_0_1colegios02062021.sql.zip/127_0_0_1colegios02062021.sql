-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2021 at 04:54 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbdd_colegios`
--
DROP DATABASE IF EXISTS `bbdd_colegios`;
CREATE DATABASE IF NOT EXISTS `bbdd_colegios` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `bbdd_colegios`;

-- --------------------------------------------------------

--
-- Table structure for table `articulos`
--

DROP TABLE IF EXISTS `articulos`;
CREATE TABLE `articulos` (
  `id` int(11) NOT NULL,
  `titulo` varchar(45) CHARACTER SET utf8mb4 NOT NULL,
  `precio` decimal(10,2) UNSIGNED ZEROFILL NOT NULL,
  `descripcion` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `talla` varchar(6) CHARACTER SET utf8mb4 NOT NULL,
  `curso` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `estado` varchar(30) CHARACTER SET utf8mb4 NOT NULL,
  `fk_usuario` int(11) NOT NULL,
  `fk_categoria` int(11) NOT NULL,
  `fk_colegio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `articulos`
--

INSERT INTO `articulos` (`id`, `titulo`, `precio`, `descripcion`, `talla`, `curso`, `estado`, `fk_usuario`, `fk_categoria`, `fk_colegio`) VALUES
(1, 'Libro de lectura', '00000005.00', 'libro de lectura para niños', '', '', '', 0, 0, 0),
(2, 'uniforme ', '00000010.00', 'Uniforme escolar colegio La merced', '10', '', '', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(1, 'Uniformes'),
(2, 'Material Escolar'),
(3, 'Material Deprotivo'),
(4, 'Libros'),
(5, 'Tecnología');

-- --------------------------------------------------------

--
-- Table structure for table `colegios`
--

DROP TABLE IF EXISTS `colegios`;
CREATE TABLE `colegios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `direccion` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `telefono` varchar(15) CHARACTER SET utf8mb4 NOT NULL,
  `codigo_centro` char(8) CHARACTER SET utf8mb4 NOT NULL,
  `web` varchar(60) CHARACTER SET utf8mb4 NOT NULL,
  `longitud` float NOT NULL,
  `latitud` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `colegios`
--

INSERT INTO `colegios` (`id`, `nombre`, `direccion`, `telefono`, `codigo_centro`, `web`, `longitud`, `latitud`) VALUES
(0, 'La Merced', 'C. Luis de Góngora, 5, 28004 Madrid', '915 23 22 99', '28013255', 'https://www.colegiolamerced.es/', 40.4241, -3.69703);

-- --------------------------------------------------------

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `numero_pedido` varchar(60) CHARACTER SET utf8mb4 NOT NULL,
  `fecha_pedido` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fk_usuario` int(11) NOT NULL,
  `fk_articulo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) CHARACTER SET utf8mb4 NOT NULL,
  `apellidos` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `telefono` varchar(15) CHARACTER SET utf8mb4 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `fk_colegio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellidos`, `email`, `telefono`, `password`, `fecha_registro`, `fk_colegio`) VALUES
(1, 'Alicia', 'García', 'ali@gmail.com', '123456789', '123456', '2021-06-02 14:46:49', 0),
(2, 'Jesica', 'Rosales', 'jesi@gmail.com', '987654321', '123456', '2021-06-02 14:46:49', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articulos`
--
ALTER TABLE `articulos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_CATEGORIA` (`fk_categoria`),
  ADD KEY `FK_USUARIO` (`fk_usuario`),
  ADD KEY `FK_COLEGIO` (`fk_colegio`);

--
-- Indexes for table `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `colegios`
--
ALTER TABLE `colegios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo_centro_UNIQUE` (`codigo_centro`);

--
-- Indexes for table `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_USUARIO` (`fk_usuario`),
  ADD KEY `FK_ARTICULO` (`fk_articulo`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD KEY `FK_COLEGIO` (`fk_colegio`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articulos`
--
ALTER TABLE `articulos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
